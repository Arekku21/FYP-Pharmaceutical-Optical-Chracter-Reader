<!DOCTYPE html>
<html>
    <head>
        <style>
            .logo-margin{
              margin-left: 13%;
            }
        </style>
    </head>
    <body>
    <div style="position: fixed; width: 100%; z-index: 1;">
    <div class="navbar-menu level " style="background-color: #150050; color: azure; padding-top: 5%;padding-left: 3%; margin-left:270px" aria-label="main navigation;">
    <p  class="menu-label" style="color: azure; font-size:18px;"> PHARMACY MANAGEMENT SYSTEM</p>

            <div class="navbar-end level-right" >
                <div class="navbar-item level-item">
                    <div class="navbar-item">
                        <p class="menu-label" style="color: azure; font-size:12px; margin-right:3%;">Pharmacist</p>
                        <form action="logout.php">
                        <input type="submit"  name="submit_btn"  value="Log Out"><i class="fas fas-sign-in" aria-hidden="true"></i>
                        </form>
                </div>
                

                    </div>
                </div>
            </div>
        </div>
    </body>
</html>
