
<!DOCTYPE html>
<html lang="en">
    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="icon" type="image/x-icon" href="favicon.ico">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">
        <link href="css/index.css" rel="stylesheet"/>
    </head>
    <body>
<?php
    /*
    Secret Page
    */

    // Start the session (Important!)
    session_start();

    include "sidebar.php";
    include "header.php";
    // Your Login Page
    $login_page = "login.php";

    // Check if user is logged in
    if($_SESSION['logged_in'] !== True){

    // Redirect to Your Login Page to Prevent Unauthorized Access
    header("Location: $login_page");
}
?>
               
    </body>
</html>