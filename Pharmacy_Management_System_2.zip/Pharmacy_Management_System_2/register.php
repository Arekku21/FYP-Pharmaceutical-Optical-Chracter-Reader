
<?php
// Include config file
require_once("config.php");

session_start();

    $auth_page = "menu/menu.php";

    // Check if the user is logged in already or not.
    if(!empty($_SESSION['logged_in'])){
        // Immediately redirect to page
        header("Location: $auth_page");
    }

$email = $password = $confirm_password = "";
$username_err = $password_err = $confirm_password_err = "";

if(isset($_POST['submit_btn'])){
    $email = $_POST['email'];
    $password = $_POST['password'];
    $password = md5($password);
    $sql = "SELECT * FROM user WHERE email = '$email'";
    $query = mysqli_query($conn, $sql);
    

if(mysqli_num_rows($query) > 0){

    echo "Email already exists";

} else {

    $signUpQuery = "INSERT INTO `user`(`email`, `password`) VALUES ( '$email', '$password')";

    if (mysqli_query($conn, $signUpQuery)) {
        echo "<script type='text/javascript'>location.href='login.php';</script>";
    } else {
        
    echo "Error: " . $signUpQuery . "<br>" . mysqli_error($conn);
    echo "<script type='text/javascript'>alert('Email already exists');</script>";
    }

 }
}
 
// Processing form data when form is submitted
if($_SERVER["REQUEST_METHOD"] == "POST"){
    
    // Validate email
    if(empty(trim($_POST["email"]))){
        $username_err = "Please enter email.";
    } elseif(!preg_match('/^[a-zA-Z0-9_]+$/', trim($_POST["email"]))){
        $username_err = "Invalid email";
    } else{
        // Prepare a select statement
        $sql = "SELECT id FROM users WHERE email = ?";

        // Validate password
    if(empty(trim($_POST["password"]))){
        $password_err = "Please enter a password.";     
    } elseif(!preg_match("^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[@$!%*?&])[A-Za-z\d@$!%*?&]{8,}$", trim($_POST['password']))){
        $password_err = "Password must contain atleast 8 letters with 1 uppercase letter, a number, and a special character.";
    } else{
        $password = trim($_POST["password"]);
    }
    
    // Validate confirm password
    if(empty(trim($_POST["confirm_password"]))){
        $confirm_password_err = "Please confirm password.";     
    } else{
        $confirm_password = trim($_POST["confirm_password"]);
        if(empty($password_err) && ($password != $confirm_password)){
            $confirm_password_err = "Password did not match.";
        }
    }

        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "s", $param_username);
            
            // Set parameters
            $param_username = trim($_POST["username"]);
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                /* store result */
                mysqli_stmt_store_result($stmt);
                
                if(mysqli_stmt_num_rows($stmt) == 1){
                    $username_err = "This username is already taken.";
                } else{
                    $username = trim($_POST["username"]);
                }
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    
}

    
    
    // Check input errors before inserting in database
    if(empty($username_err) && empty($password_err) && empty($confirm_password_err)){
        
        // Prepare an insert statement
        $sql = "INSERT INTO users (email, password) VALUES (?, ?)";
         
        if($stmt = mysqli_prepare($link, $sql)){
            // Bind variables to the prepared statement as parameters
            mysqli_stmt_bind_param($stmt, "ss", $param_username, $param_password);
            
            // Set parameters
            $param_username = $username;
            $param_password = password_hash($password, PASSWORD_DEFAULT); // Creates a password hash
            
            // Attempt to execute the prepared statement
            if(mysqli_stmt_execute($stmt)){
                // Redirect to login page
                header("location: login.php");
            } else{
                echo "Oops! Something went wrong. Please try again later.";
            }

            // Close statement
            mysqli_stmt_close($stmt);
        }
    }
    // Close connection
    mysqli_close($link);

?>

<!DOCTYPE html>
<html>
<head>
        <script src='http://cdnjs.cloudflare.com/ajax/libs/jquery/2.1.3/jquery.min.js'></script>
        <script type="text/javascript" src="https://www.gstatic.com/charts/loader.js"></script>
        <meta name="viewport" content="width=device-width, initial-scale=1" charset="UTF-8">
        <script src="https://www.gstatic.com/charts/loader.js"></script>
        <script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <link rel="icon" type="image/x-icon" href="favicon.ico">
        <link href="https://fonts.googleapis.com/css?family=Roboto:300,400,500&display=swap" rel="stylesheet">
        <link href="https://fonts.googleapis.com/icon?family=Material+Icons" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/bulma/0.7.5/css/bulma.css" rel="stylesheet">
        <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.11.2/css/all.min.css" rel="stylesheet">
        <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
        <link href="css/index.css" rel="stylesheet"/>
        <title>Register</title>
</head>

<body><div class="container" style="background-color: #041221;max-width: none;margin-top: +2%;">
            <div id="flow">
                <span class="flow-1"></span>
                <span class="flow-2"></span>
                <span class="flow-3"></span>
            </div>
            <div class="section" >
        
            <section class="hero is-success is-fullheight">
                <div class="hero-body">
                    <div class="container has-text-centered" style="max-width: 1132px;">
                        <div class="column is-4 is-offset-4">
                        <div class="login-header">
                                <h3 class="title ">Register</h3>
                                <hr class="login-hr">

                <div class="box">
                <form action="register.php" method="post">
                <fieldset>
                    <div class="field">
                        <div class="control">
                        <label>Email</label>
                        <input type="email" name="email" class="form-control  <?php echo (!empty($username_err)) ? 'is-invalid' : ''; ?>">
                        <span class="invalid-feedback"><?php echo $username_err; ?></span>
                        </div>
                    </div>    


                    <div class="field">
                    <div class="control">    
                            <label>Password</label>
                            <input type="password" name="password" class="form-control <?php echo (!empty($password_err)) ? 'is-invalid' : ''; ?>">
                            <span class="invalid-feedback"><?php echo $password_err; ?></span>
                    </div>
                    </div>


                    <div class="field">
                    <div class="control">   
                        <label>Confirm Password</label>
                        <input type="password" name="confirm_password" class="form-control <?php echo (!empty($confirm_password_err)) ? 'is-invalid' : ''; ?>" >
                        <span class="invalid-feedback"><?php echo $confirm_password_err; ?></span>
                    </div>
                    </div>


            <div class="form-group">
                <input type="submit"  name="submit_btn" class="button is-block is-primary is-medium is-fullwidth" value="Sign Up"><i class="fas fas-sign-in" aria-hidden="true"></i>
            </div>
            <p>Already have an account? <a href="login.php">Login here</a>.</p>
        </form>
        <a class=" level-item logo-margin" >
                              <img src="image/logo.png" width="152" height="140">
                            </a>
    </div>    
</body>
</html>
